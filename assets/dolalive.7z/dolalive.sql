/*
Navicat MySQL Data Transfer

Source Server         : hq-mysql-1:22306
Source Server Version : 50623
Source Host           : 127.0.0.1:22306
Source Database       : dolalive

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2015-10-28 11:29:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `h_house_project`
-- ----------------------------
DROP TABLE IF EXISTS `h_house_project`;
CREATE TABLE `h_house_project` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `PROJECT_NAME` varchar(64) DEFAULT NULL,
  `PROJECT_DESC` varchar(512) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of h_house_project
-- ----------------------------
INSERT INTO `h_house_project` VALUES ('1', '康桥悦岛', null, '2015-10-28 09:49:45', '1');
INSERT INTO `h_house_project` VALUES ('2', '紫域澜庭', null, '2015-10-29 09:49:49', '1');
INSERT INTO `h_house_project` VALUES ('3', '新芒果春天', null, '2015-10-30 09:49:54', '1');
INSERT INTO `h_house_project` VALUES ('4', '二七金运外滩', null, '2015-09-30 09:49:58', '1');
INSERT INTO `h_house_project` VALUES ('5', '恒大翡翠华庭', null, '2015-10-23 09:50:04', '1');

-- ----------------------------
-- Table structure for `p_comment`
-- ----------------------------
DROP TABLE IF EXISTS `p_comment`;
CREATE TABLE `p_comment` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `PID` varchar(32) DEFAULT NULL,
  `CONTENT` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(1) DEFAULT NULL,
  `SOURCE_ID` varchar(32) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_comment
-- ----------------------------
INSERT INTO `p_comment` VALUES ('1', null, '超级管理员', '2015-10-27 16:09:48', '1', null, null);
INSERT INTO `p_comment` VALUES ('2', null, '管理员', '2015-10-28 16:09:53', '2', null, null);
INSERT INTO `p_comment` VALUES ('3', null, '游客', '2015-10-29 16:09:58', '1', null, null);

-- ----------------------------
-- Table structure for `p_customer`
-- ----------------------------
DROP TABLE IF EXISTS `p_customer`;
CREATE TABLE `p_customer` (
  `id` varchar(32) NOT NULL,
  `USER_NAME` varchar(32) DEFAULT NULL,
  `USER_PASS` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  `AVATAR_URL` varchar(128) DEFAULT NULL,
  `EMAIL` varchar(64) DEFAULT NULL,
  `MOBILE` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_customer
-- ----------------------------
INSERT INTO `p_customer` VALUES ('1', 'mega', '123', '2015-09-30 16:33:09', '1', '20150930/98f27174616d4c40a6be87ab827e90b7.png', '3203317@qq.com', '13837186852');

-- ----------------------------
-- Table structure for `s_manager`
-- ----------------------------
DROP TABLE IF EXISTS `s_manager`;
CREATE TABLE `s_manager` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `USER_NAME` varchar(32) DEFAULT NULL,
  `USER_PASS` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_manager
-- ----------------------------
INSERT INTO `s_manager` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2015-10-27 16:09:48', '1');
INSERT INTO `s_manager` VALUES ('2', 'hx', 'e10adc3949ba59abbe56e057f20f883e', '2015-10-28 16:09:53', '2');
INSERT INTO `s_manager` VALUES ('3', 'wp', 'e10adc3949ba59abbe56e057f20f883e', '2015-10-29 16:09:58', '1');
INSERT INTO `s_manager` VALUES ('4', 'hq', 'e10adc3949ba59abbe56e057f20f883e', '2015-10-30 16:10:02', '1');

-- ----------------------------
-- Table structure for `s_menu`
-- ----------------------------
DROP TABLE IF EXISTS `s_menu`;
CREATE TABLE `s_menu` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `pid` varchar(32) DEFAULT NULL,
  `menu_name` varchar(32) DEFAULT NULL,
  `menu_url` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_menu
-- ----------------------------
INSERT INTO `s_menu` VALUES ('1', '0', '美食', null);
INSERT INTO `s_menu` VALUES ('2', '0', '娱乐', null);
INSERT INTO `s_menu` VALUES ('3', '0', '出行', null);
INSERT INTO `s_menu` VALUES ('4', '0', '管家', null);
INSERT INTO `s_menu` VALUES ('5', '0', '住房', null);
INSERT INTO `s_menu` VALUES ('6', '0', '美保', null);
INSERT INTO `s_menu` VALUES ('7', '0', '配送', null);
INSERT INTO `s_menu` VALUES ('8', '0', '其他', null);

-- ----------------------------
-- Table structure for `s_role`
-- ----------------------------
DROP TABLE IF EXISTS `s_role`;
CREATE TABLE `s_role` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `ROLE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(1) DEFAULT NULL,
  `ROLE_DESC` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_role
-- ----------------------------
INSERT INTO `s_role` VALUES ('1', '超级管理员', '2015-10-27 16:09:48', '1', null);
INSERT INTO `s_role` VALUES ('2', '管理员', '2015-10-28 16:09:53', '2', null);
INSERT INTO `s_role` VALUES ('3', '游客', '2015-10-29 16:09:58', '1', null);

-- ----------------------------
-- Table structure for `s_user`
-- ----------------------------
DROP TABLE IF EXISTS `s_user`;
CREATE TABLE `s_user` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `user_name` varchar(32) DEFAULT NULL,
  `user_pass` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_user
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_menu`
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` varchar(111) NOT NULL DEFAULT '',
  `PID` varchar(111) DEFAULT NULL,
  `MENU_NAME` varchar(32) DEFAULT NULL,
  `MENU_URL` varchar(128) DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL,
  `ISPARENT` int(11) DEFAULT NULL,
  `PATH` varchar(1000) DEFAULT NULL,
  `TYPE` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('1', '0', '后台', null, '1', '1', '0', '1');
INSERT INTO `sys_menu` VALUES ('10', '8', '角色权限设置', null, '2', '0', '0,1,4,8', '1');
INSERT INTO `sys_menu` VALUES ('11', '4', '用户管理', null, '3', '1', '0,1,4', '1');
INSERT INTO `sys_menu` VALUES ('12', '11', '用户信息维护', 'manager/', '1', '0', '0,1,4,11', '1');
INSERT INTO `sys_menu` VALUES ('13', '11', '用户角色设置', null, '2', '0', '0,1,4,11', '1');
INSERT INTO `sys_menu` VALUES ('14', '4', '动作管理', null, '4', '1', '0,1,4', '1');
INSERT INTO `sys_menu` VALUES ('15', '14', '动作信息维护', 'action/', '1', '0', '0,1,4,14', '1');
INSERT INTO `sys_menu` VALUES ('16', '4', '数据权限', null, '5', '1', '0,1,4', '1');
INSERT INTO `sys_menu` VALUES ('17', '16', '数据规则设置', null, '1', '0', '0,1,4,16', '1');
INSERT INTO `sys_menu` VALUES ('18', '1', '网站管理', null, '3', '1', '0,1', '1');
INSERT INTO `sys_menu` VALUES ('19', '18', '评论管理', null, '1', '1', '0,1,18', '1');
INSERT INTO `sys_menu` VALUES ('2', '4', '基本设置', null, '1', '1', '0,1,4', '1');
INSERT INTO `sys_menu` VALUES ('20', '19', '评论信息维护', 'comment/', '1', '0', '0,1,18,19', '1');
INSERT INTO `sys_menu` VALUES ('21', '0', '前台', null, '4', '1', '0', '1');
INSERT INTO `sys_menu` VALUES ('22', '18', '客户管理', null, '1', '1', '0,1,18', '1');
INSERT INTO `sys_menu` VALUES ('23', '22', '客户信息维护', 'customer/', '1', '0', '0,1,18,22', '1');
INSERT INTO `sys_menu` VALUES ('24', '22', '用户信息维护', 'tenantuser/index', '4', '0', '0,21,22', '1');
INSERT INTO `sys_menu` VALUES ('25', '22', '服务订单维护', 'softserviceorder/index', '2', '0', '0,21,22', '1');
INSERT INTO `sys_menu` VALUES ('26', '22', '组织机构维护', 'tenantorg/index', '3', '0', '0,21,22', '1');
INSERT INTO `sys_menu` VALUES ('27', '1', '日志管理', null, '5', '1', '0,1', '1');
INSERT INTO `sys_menu` VALUES ('28', '18', '房产管理', null, '3', '1', '0,1,18', '1');
INSERT INTO `sys_menu` VALUES ('29', '28', '项目管理', 'house/project/', '1', '0', '0,1,18,28', '1');
INSERT INTO `sys_menu` VALUES ('3', '2', '参数设置', null, '1', '0', '0,1,4,2', '1');
INSERT INTO `sys_menu` VALUES ('4', '1', '系统管理', null, '2', '1', '0,1', '1');
INSERT INTO `sys_menu` VALUES ('5', '4', '菜单管理', null, '1', '1', '0,1,4', '1');
INSERT INTO `sys_menu` VALUES ('6', '5', '菜单信息维护', 'menu/', '1', '0', '0,1,4,5', '1');
INSERT INTO `sys_menu` VALUES ('7', '5', '菜单操作注册', null, '2', '0', '0,1,4,5', '1');
INSERT INTO `sys_menu` VALUES ('8', '4', '角色管理', null, '2', '1', '0,1,4', '1');
INSERT INTO `sys_menu` VALUES ('9', '8', '角色信息维护', 'role/', '1', '0', '0,1,4,8', '1');

-- ----------------------------
-- Table structure for `w_ad`
-- ----------------------------
DROP TABLE IF EXISTS `w_ad`;
CREATE TABLE `w_ad` (
  `id` varchar(32) NOT NULL,
  `AD_NAME` varchar(32) DEFAULT NULL COMMENT '广告名称',
  `START_TIME` datetime DEFAULT NULL COMMENT '开始时间',
  `END_TIME` datetime DEFAULT NULL COMMENT '结束时间',
  `SORT` int(11) DEFAULT NULL,
  `AD_PIC` varchar(256) DEFAULT NULL,
  `AD_TYPE` varchar(32) DEFAULT NULL COMMENT '广告类型',
  `CORP_ID` varchar(32) DEFAULT NULL,
  `ZONE_ID` varchar(32) DEFAULT NULL,
  `PAGE_POSITION_ID` varchar(32) DEFAULT NULL,
  `LINK_URL` varchar(128) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `CREATE_USER_ID` varchar(32) DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告';

-- ----------------------------
-- Records of w_ad
-- ----------------------------
INSERT INTO `w_ad` VALUES ('058526f3a2d84ffb8d4736c136ee4207', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '1', '20150928/58babb5b6df84e569e50a8fd3b367a4a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('1', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '7', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('111', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '1', '20150928/58babb5b6df84e569e50a8fd3b367a4a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('2', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '8', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('222', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '2', '20150928/573cd8d72c2b4b8d8b4b5f6b47bba265.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('2463a20ded434a5c860a00f909965e2e', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '19', '20150928/2463a20ded434a5c860a00f909965e2e.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', '6af9c938060944df8225ab18e2bea621', '8eff5b4b478844b383e54a8e5c98449a', '9b484e073d9b4201859650551f52f5eb', '1.html', null, null, '1');
INSERT INTO `w_ad` VALUES ('3', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '9', '20150928/58babb5b6df84e569e50a8fd3b367a4a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('333', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '1', '20150928/2d93bacdc80d4791b90cdbc82d0377ee.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '258e597a238a471e8b052d5f9c806072', '333.html', null, null, '1');
INSERT INTO `w_ad` VALUES ('3333', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '3', '20150928/ac39ebc537c54489b83d51ccc101ef42.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('4', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '10', '20150928/573cd8d72c2b4b8d8b4b5f6b47bba265.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('444', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '2', '20150928/f611abfa21964c2a891768455acd1213.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '258e597a238a471e8b052d5f9c806072', '444.html', null, null, '1');
INSERT INTO `w_ad` VALUES ('4444', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '4', '20150928/d43edaa0e8274daba9b5c1ec4bb8d23a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('5', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '11', '20150928/ac39ebc537c54489b83d51ccc101ef42.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('555', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '3', '20150928/77b69dce8b1a46b1a4a47294efa98d29.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '258e597a238a471e8b052d5f9c806072', '555.html', null, null, '1');
INSERT INTO `w_ad` VALUES ('5555', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '5', '20150928/d274a85e06244885888ba231979d9397.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('6', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '12', '20150928/d43edaa0e8274daba9b5c1ec4bb8d23a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('652f5fc3bfe2450c86685dce373c2d70', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '5', '20150928/652f5fc3bfe2450c86685dce373c2d70.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', '6af9c938060944df8225ab18e2bea621', '8eff5b4b478844b383e54a8e5c98449a', '9b484e073d9b4201859650551f52f5eb', '2.html', null, null, '1');
INSERT INTO `w_ad` VALUES ('6666', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '6', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('7', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '13', '20150928/d274a85e06244885888ba231979d9397.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('7777', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '7', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('8', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '14', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('841ede8c0a9943cb9f2714e9dc840e5a', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '2', '20150928/573cd8d72c2b4b8d8b4b5f6b47bba265.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', '7126ea5c2c8f4177a756e87433d04bf6', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('8888', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '8', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('8a9ad3c1a79d42ed8c8b9dfe341dd43d', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '3', '20150928/ac39ebc537c54489b83d51ccc101ef42.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('9', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '15', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('9999', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '9', '20150928/58babb5b6df84e569e50a8fd3b367a4a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('a44a718bf7be464d8658e5ef14b4427f', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '4', '20150928/d43edaa0e8274daba9b5c1ec4bb8d23a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('asdf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '11', '20150928/ac39ebc537c54489b83d51ccc101ef42.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('asdfadfsadfasdfasd', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '15', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('asdfasdf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '12', '20150928/d43edaa0e8274daba9b5c1ec4bb8d23a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('asdfsdf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '13', '20150928/d274a85e06244885888ba231979d9397.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('asdfwer', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '15', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('asfasdfsdaf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '16', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('bbbvxcvbxcvb', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '15', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('bvcbxcv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '14', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('bvn', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '7', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('bxcbxcv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '3', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('bxcv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '10', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('bxcvb', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '4', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('bxcvcbb', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '11', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('cb', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '8', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('cdfaedb7bb624f66902befaa10dbec27', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '20', '20150928/cdfaedb7bb624f66902befaa10dbec27.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'cf3d26e2cf0049d08fed02cdebc9c9cf', '8eff5b4b478844b383e54a8e5c98449a', '9b484e073d9b4201859650551f52f5eb', '3.html', null, null, '1');
INSERT INTO `w_ad` VALUES ('cv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '9', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('cvbcvxb', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '12', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('cvbxcvvxcxcb', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '13', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('cvxb', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '1', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('cvxbzvczxvc', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '5', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('cvxvcbzvzcv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '16', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('d1e1b3b9d0c24c8494c7fbe0e36921f2', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '5', '20150928/d274a85e06244885888ba231979d9397.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('d9a99f80e5b5409b8c166c1fe6afa7af', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '6', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '841ede8c0a9943cb9f2714e9dc840e5a', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('dafdfasdfasdf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '17', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('dfgh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '8', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('dfghfghfg', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '10', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('dgh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '9', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('fg', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '6', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('fgh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '11', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('fghsss', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '12', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('g', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '19', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('gh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '2', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('ghj', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '1', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('ghjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '12', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('ghjkfh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '5', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('ghjkghjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '18', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('ghkgkgk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '3', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('gkkggkgjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '5', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('h', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '6', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('hdf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '7', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('hdfkjj', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '1', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', 'jk', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('hg', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '14', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('hgk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '13', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('hjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '23', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('hjkghjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '17', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('hkggkhgk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '2', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jgh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '3', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jghj', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '4', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jhkhjkh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '21', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jkgh', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '10', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jkhjkhjkghjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '9', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jkhjkjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '20', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jkjhk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '22', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('jkk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '8', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('k', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '4', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('khj', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '15', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('khkg', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '16', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('kjhjkghjk', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '11', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('kkgkgjkg', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '7', '20150928/f77fb0f0cdc84ca4b82373b523e759ea.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', 'e24045b09ee34f6881188019ab8917b9', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('sadf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '10', '20150928/573cd8d72c2b4b8d8b4b5f6b47bba265.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('sadf31', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '19', '20150928/ac39ebc537c54489b83d51ccc101ef42.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('sdfasdf', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '14', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('sdfgsfgsdfgq', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '14', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('sgfdgsdfg', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '13', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '08ccf8258cb0469d8e10fbb7b7ec3667', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('vbvbv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '6', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('vcxvzcvzxcvz', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '21', '20150928/e8359831a14c424c804861754fe3f415.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('vzxcvxzcvzxc', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '17', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('wer', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '17', '20150928/58babb5b6df84e569e50a8fd3b367a4a.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('werq', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '18', '20150928/573cd8d72c2b4b8d8b4b5f6b47bba265.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('werwer', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '16', '20150928/fe42bef3c433491885bfab76269b718d.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '60b33f3be6d0481884e1cda8b2155b34', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('xc', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '2', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('zcvzxcvzxbnbvnbv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '20', '20150928/e8359831a14c424c804861754fe3f415.jpg', null, 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('zxcvvzxcvzxcv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '18', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');
INSERT INTO `w_ad` VALUES ('zxcvzxcvzxcv', null, '2015-08-24 17:51:03', '2015-12-31 01:01:01', '19', '20150928/e8359831a14c424c804861754fe3f415.jpg', '3cfa3945f6cc4b468a13f8c6d5d4f473', 'aa4bcd4b0e034243be6054e0635066aa', '8eff5b4b478844b383e54a8e5c98449a', '971769765f9c4a5d98372529cf483090', null, null, null, '1');

-- ----------------------------
-- Table structure for `w_ad_ext`
-- ----------------------------
DROP TABLE IF EXISTS `w_ad_ext`;
CREATE TABLE `w_ad_ext` (
  `PID` varchar(32) DEFAULT NULL,
  `_KEY` varchar(32) DEFAULT NULL,
  `_VALUE` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告扩展';

-- ----------------------------
-- Records of w_ad_ext
-- ----------------------------

-- ----------------------------
-- Table structure for `w_ad_type`
-- ----------------------------
DROP TABLE IF EXISTS `w_ad_type`;
CREATE TABLE `w_ad_type` (
  `id` varchar(32) NOT NULL,
  `TYPE_NAME` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告类型';

-- ----------------------------
-- Records of w_ad_type
-- ----------------------------
INSERT INTO `w_ad_type` VALUES ('3cfa3945f6cc4b468a13f8c6d5d4f473', '商家宣传');
INSERT INTO `w_ad_type` VALUES ('7ce9818342a14fad8e84c3f75765956e', '（优惠）活动');
INSERT INTO `w_ad_type` VALUES ('81413741eba7458a8381e775c0155fd1', '商品宣传');

-- ----------------------------
-- Table structure for `w_corp`
-- ----------------------------
DROP TABLE IF EXISTS `w_corp`;
CREATE TABLE `w_corp` (
  `id` varchar(32) NOT NULL,
  `FULL_NAME` varchar(32) DEFAULT NULL,
  `CORP_NAME` varchar(32) DEFAULT NULL,
  `CORP_LOGO` varchar(256) DEFAULT NULL,
  `GOODS_TYPE_ID` varchar(32) DEFAULT NULL COMMENT '商品类型',
  `DISTRICT_ID` varchar(32) DEFAULT NULL,
  `ADDR` varchar(256) DEFAULT NULL COMMENT '具体地址',
  `LNG` varchar(32) DEFAULT NULL COMMENT '经度',
  `LAT` varchar(32) DEFAULT NULL COMMENT '纬度',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `CREATE_USER_ID` varchar(32) DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公司';

-- ----------------------------
-- Records of w_corp
-- ----------------------------
INSERT INTO `w_corp` VALUES ('6af9c938060944df8225ab18e2bea621', '商铺2', 'corp_2', null, '1', '2', null, null, null, null, null, '1');
INSERT INTO `w_corp` VALUES ('7126ea5c2c8f4177a756e87433d04bf6', '商铺4', 'corp_4', null, '1', '4', null, null, null, null, null, '1');
INSERT INTO `w_corp` VALUES ('aa4bcd4b0e034243be6054e0635066aa', '商铺3', 'corp_3', null, '1', '3', null, null, null, null, null, '1');
INSERT INTO `w_corp` VALUES ('cf3d26e2cf0049d08fed02cdebc9c9cf', '商铺1', 'corp_1', null, '1', '1', null, null, null, null, null, '1');

-- ----------------------------
-- Table structure for `w_corp_ext`
-- ----------------------------
DROP TABLE IF EXISTS `w_corp_ext`;
CREATE TABLE `w_corp_ext` (
  `PID` varchar(32) DEFAULT NULL,
  `_KEY` varchar(32) DEFAULT NULL,
  `_VAL` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='企业扩展表';

-- ----------------------------
-- Records of w_corp_ext
-- ----------------------------

-- ----------------------------
-- Table structure for `w_corp_user`
-- ----------------------------
DROP TABLE IF EXISTS `w_corp_user`;
CREATE TABLE `w_corp_user` (
  `id` varchar(32) NOT NULL,
  `CORP_ID` varchar(32) DEFAULT NULL,
  `USER_NAME` varchar(32) DEFAULT NULL,
  `USER_PASS` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `CREATE_USER_ID` varchar(32) DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公司用户';

-- ----------------------------
-- Records of w_corp_user
-- ----------------------------

-- ----------------------------
-- Table structure for `w_customer`
-- ----------------------------
DROP TABLE IF EXISTS `w_customer`;
CREATE TABLE `w_customer` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `user_name` varchar(32) DEFAULT NULL,
  `user_pass` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of w_customer
-- ----------------------------

-- ----------------------------
-- Table structure for `w_district`
-- ----------------------------
DROP TABLE IF EXISTS `w_district`;
CREATE TABLE `w_district` (
  `id` varchar(32) NOT NULL,
  `ZONE_ID` varchar(256) DEFAULT NULL,
  `DISTRICT_NAME` varchar(32) DEFAULT NULL COMMENT '商圈名称',
  `SORT` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商圈';

-- ----------------------------
-- Records of w_district
-- ----------------------------
INSERT INTO `w_district` VALUES ('1', '3', '紫荆山', '1');
INSERT INTO `w_district` VALUES ('10', '6', '万达广场', '5');
INSERT INTO `w_district` VALUES ('2', '3', '二七广场', '2');
INSERT INTO `w_district` VALUES ('3', '3', '郑东新区', '3');
INSERT INTO `w_district` VALUES ('4', '3', '中原大桥', '4');
INSERT INTO `w_district` VALUES ('5', '3', '国贸360广场', '5');
INSERT INTO `w_district` VALUES ('6', '6', '新都汇', '1');
INSERT INTO `w_district` VALUES ('7', '6', '唐宫路', '2');
INSERT INTO `w_district` VALUES ('8', '6', '宝龙广场', '3');
INSERT INTO `w_district` VALUES ('9', '6', '上海市场', '4');

-- ----------------------------
-- Table structure for `w_goods`
-- ----------------------------
DROP TABLE IF EXISTS `w_goods`;
CREATE TABLE `w_goods` (
  `id` varchar(32) NOT NULL,
  `SHOP_ID` varchar(32) DEFAULT NULL,
  `GOODS_TYPE_ID` varchar(32) DEFAULT NULL,
  `GOODS_NAME` varchar(32) DEFAULT NULL COMMENT '商品名称',
  `GOODS_PIC` varchar(64) DEFAULT NULL,
  `GOODS_PRICE` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品';

-- ----------------------------
-- Records of w_goods
-- ----------------------------
INSERT INTO `w_goods` VALUES ('1', '1', '9', '香蕉', null, '89');
INSERT INTO `w_goods` VALUES ('2', '1', '9', '苹果', null, '23');
INSERT INTO `w_goods` VALUES ('3', '2', '10', '哈密瓜', null, '54');
INSERT INTO `w_goods` VALUES ('4', '2', '10', '草莓', null, '655');
INSERT INTO `w_goods` VALUES ('5', '2', '10', '芒果', null, '423');
INSERT INTO `w_goods` VALUES ('6', '4', '10', '水蜜桃', null, '8956');

-- ----------------------------
-- Table structure for `w_goods_type`
-- ----------------------------
DROP TABLE IF EXISTS `w_goods_type`;
CREATE TABLE `w_goods_type` (
  `id` varchar(32) NOT NULL,
  `PID` varchar(32) DEFAULT NULL,
  `PATH` varchar(512) DEFAULT NULL,
  `TYPE_NAME` varchar(32) DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='美食';

-- ----------------------------
-- Records of w_goods_type
-- ----------------------------
INSERT INTO `w_goods_type` VALUES ('1', '0', '0', '美食', '1');
INSERT INTO `w_goods_type` VALUES ('10', '1', '0,1', '蔬菜', '2');
INSERT INTO `w_goods_type` VALUES ('2', '0', '0', '娱乐', '2');
INSERT INTO `w_goods_type` VALUES ('3', '0', '0', '出行', '3');
INSERT INTO `w_goods_type` VALUES ('4', '0', '0', '管家', '4');
INSERT INTO `w_goods_type` VALUES ('5', '0', '0', '住房', '5');
INSERT INTO `w_goods_type` VALUES ('6', '0', '0', '美保', '6');
INSERT INTO `w_goods_type` VALUES ('7', '0', '0', '配送', '7');
INSERT INTO `w_goods_type` VALUES ('8', '0', '0', '其他', '8');
INSERT INTO `w_goods_type` VALUES ('9', '2', '0,2', '水果', '1');

-- ----------------------------
-- Table structure for `w_page`
-- ----------------------------
DROP TABLE IF EXISTS `w_page`;
CREATE TABLE `w_page` (
  `id` varchar(32) NOT NULL,
  `PATH` varchar(128) DEFAULT NULL,
  `PAGE_NAME` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of w_page
-- ----------------------------
INSERT INTO `w_page` VALUES ('12a59ed2eb964fe88c4b1d84e06600d2', '/w/:wifi_mac/', '通过WIFI登陆入口');
INSERT INTO `w_page` VALUES ('dad9657792274e0e95a15c8901573c11', '/:zone/', '地区首页');

-- ----------------------------
-- Table structure for `w_page_position`
-- ----------------------------
DROP TABLE IF EXISTS `w_page_position`;
CREATE TABLE `w_page_position` (
  `id` varchar(32) NOT NULL,
  `POSITION_NAME` varchar(32) DEFAULT NULL COMMENT '广告位名称',
  `PREVIEW_PIC` varchar(64) DEFAULT NULL COMMENT '预览图片',
  `PAGE_ID` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of w_page_position
-- ----------------------------
INSERT INTO `w_page_position` VALUES ('08ccf8258cb0469d8e10fbb7b7ec3667', '休闲娱乐', null, 'dad9657792274e0e95a15c8901573c11');
INSERT INTO `w_page_position` VALUES ('258e597a238a471e8b052d5f9c806072', '三个固定广告', null, 'dad9657792274e0e95a15c8901573c11');
INSERT INTO `w_page_position` VALUES ('60b33f3be6d0481884e1cda8b2155b34', '美食小吃', null, 'dad9657792274e0e95a15c8901573c11');
INSERT INTO `w_page_position` VALUES ('8', '顶部活动广告', null, '12a59ed2eb964fe88c4b1d84e06600d2');
INSERT INTO `w_page_position` VALUES ('841ede8c0a9943cb9f2714e9dc840e5a', '推荐附近', null, 'dad9657792274e0e95a15c8901573c11');
INSERT INTO `w_page_position` VALUES ('971769765f9c4a5d98372529cf483090', '生活服务', null, 'dad9657792274e0e95a15c8901573c11');
INSERT INTO `w_page_position` VALUES ('9b484e073d9b4201859650551f52f5eb', '顶部活动广告', null, 'dad9657792274e0e95a15c8901573c11');
INSERT INTO `w_page_position` VALUES ('e24045b09ee34f6881188019ab8917b9', '特色旅游', null, 'dad9657792274e0e95a15c8901573c11');

-- ----------------------------
-- Table structure for `w_page_position_ext`
-- ----------------------------
DROP TABLE IF EXISTS `w_page_position_ext`;
CREATE TABLE `w_page_position_ext` (
  `PID` varchar(32) DEFAULT NULL,
  `_KEY` varchar(32) DEFAULT NULL COMMENT '键',
  `_VALUE` varchar(4000) DEFAULT NULL COMMENT '值'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告位扩展表';

-- ----------------------------
-- Records of w_page_position_ext
-- ----------------------------
INSERT INTO `w_page_position_ext` VALUES ('9b484e073d9b4201859650551f52f5eb', 'a', '1');
INSERT INTO `w_page_position_ext` VALUES ('9b484e073d9b4201859650551f52f5eb', 'b', '2');
INSERT INTO `w_page_position_ext` VALUES ('12a59ed2eb964fe88c4b1d84e06600d2', 'c', '3');

-- ----------------------------
-- Table structure for `w_wifi`
-- ----------------------------
DROP TABLE IF EXISTS `w_wifi`;
CREATE TABLE `w_wifi` (
  `id` varchar(32) NOT NULL,
  `WIFI_MAC` varchar(32) DEFAULT NULL,
  `WIFI_NAME` varchar(32) DEFAULT NULL,
  `ADDR` varchar(128) DEFAULT NULL COMMENT '具体地址',
  `ZONE_ID` varchar(32) DEFAULT NULL COMMENT '区域',
  `LNG` varchar(32) DEFAULT NULL COMMENT '经度',
  `LAT` varchar(32) DEFAULT NULL COMMENT '纬度',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of w_wifi
-- ----------------------------
INSERT INTO `w_wifi` VALUES ('1', '00014280317A', '正森', null, '4', null, null);

-- ----------------------------
-- Table structure for `w_zone`
-- ----------------------------
DROP TABLE IF EXISTS `w_zone`;
CREATE TABLE `w_zone` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `PID` varchar(32) DEFAULT NULL,
  `PATH` varchar(512) DEFAULT NULL,
  `ZONE_NAME` varchar(32) DEFAULT NULL,
  `SORT` int(4) DEFAULT NULL,
  `LONG_NAME` varchar(32) DEFAULT NULL,
  `SHORT_NAME` varchar(32) DEFAULT NULL,
  `IS_OPEN` int(11) DEFAULT NULL,
  `IS_DEF_SITE` int(11) DEFAULT NULL,
  `SHORT_ZONE_NAME` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of w_zone
-- ----------------------------
INSERT INTO `w_zone` VALUES ('10', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '新密市', '10', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('11', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '巩义市', '11', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('12', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '登封市', '12', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('13', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '中牟县', '13', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('14', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '上街区', '14', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('15', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '荥阳市', '15', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('16', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '其他', '16', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('17', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '涧西区', '1', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('18', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '西工区', '2', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('19', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '洛龙区', '3', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('1cca0be97ca646af841bea553caa9fc4', '9b7a08f9f58f44c18f20f3848f3fa468', '0', '洛阳市', '2', 'luoyang', 'ly', '1', '1', '洛阳');
INSERT INTO `w_zone` VALUES ('20', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '老城区', '4', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('21', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '栾川县', '5', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('22', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '伊川县', '6', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('23', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '瀍河回族区', '7', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('24', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '宜阳县', '8', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('25', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '新安县', '9', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('26', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '偃师市', '10', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('27', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '孟津县', '11', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('28', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '高新区', '12', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('29', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '汝阳县', '13', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('30', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '洛宁县', '14', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('31', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '吉利区', '15', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('32', '1cca0be97ca646af841bea553caa9fc4', '0,1cca0be97ca646af841bea553caa9fc4', '嵩县', '16', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('4', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '金水区', '4', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('5', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '二七区', '5', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('6', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '中原区', '6', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('7', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '管城区', '7', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('8', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '惠济区', '8', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('8eff5b4b478844b383e54a8e5c98449a', '9b7a08f9f58f44c18f20f3848f3fa468', '0', '郑州市', '1', 'zhengzhou', 'zz', '1', '0', '郑州');
INSERT INTO `w_zone` VALUES ('9', '8eff5b4b478844b383e54a8e5c98449a', '0,9b7a08f9f58f44c18f20f3848f3fa468', '新郑市', '9', null, null, '0', '0', null);
INSERT INTO `w_zone` VALUES ('9b7a08f9f58f44c18f20f3848f3fa468', '0', '0', '河南省', '1', null, null, '0', '0', null);
